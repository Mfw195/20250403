
clc;
clear;
addpath(genpath('./segy'));
rmpath(genpath('./segy'));
Data= altreadsegy('segy_new_new.sgy');